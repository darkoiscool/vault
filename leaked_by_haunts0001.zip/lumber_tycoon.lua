_G.BloodKey = "AV110220221615oddyHackeroddyHockeyAV110220221615"
loadstring(game:HttpGet("https://raw.githubusercontent.com/BloodStillCool/666blood666/main/v17.00FREEdoNOTbuy2"))()