getgenv().serverhop = true
loadstring(game:HttpGet('https://raw.githubusercontent.com/laderite/zenx/main/scripts/Untitled_Hood_New_Autofarm.lua'))()