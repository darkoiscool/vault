loadstring(game:HttpGet("https://projectevo.xyz/script/loader.lua"))()
