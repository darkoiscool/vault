local _ = loadstring(game:HttpGet("https://raw.githubusercontent.com/bloodball/-back-ups-for-libs/main/sol"))()
local b = _:New({Name = "                                      Skin Changer", FolderToSave = "SolarisLibStuff"})
local _ = b:Tab("Info")
local a = _:Section("Click for message")
local _ = b:Tab("Tryhard")
local j = _:Section("Tryhard")
local _ = b:Tab("Faces")
local f = _:Section("MainFaces")
local d = _:Section("Beast Mode")
local e = _:Section("Bubble Trouble")
local g = _:Section("Others")
local b = b:Tab("Headless / Korblox")
local _ = b:Section("Headless")
local b = b:Section("Korblox")

a:Button(
    "Credits",
    function()
        local _ = game:GetService("StarterGui")
        _:SetCore("SendNotification", {Title = "Credits:", Text = "aori#0001", Duration = 15})
    end
)
a:Button(
    "Discord Server",
    function()
        local _ = game:GetService("StarterGui")
        _:SetCore("SendNotification", {Title = "Discord", Text = "Copied to your clipboard", Duration = 15})
        wait(0.5)
        setclipboard("discord.gg/corrupted | aori#0001")
    end
)
j:Button(
    "Tecky Hair",
    function()
        function l(a, _)
            local b = Instance.new("Weld")
            b.Part0 = a.Parent
            b.Part1 = _.Parent
            b.C0 = a.CFrame
            b.C1 = _.CFrame
            b.Parent = a.Parent
            return b
        end
        local function _(_, a, b, d, c, e)
            local f = Instance.new("Weld")
            f.Name = _
            f.Part0 = b
            f.Part1 = d
            f.C0 = c
            f.C1 = e
            f.Parent = a
            return f
        end
        local function a(_, b)
            for _, _ in pairs(_:GetChildren()) do
                if _:IsA("Attachment") and _.Name == b then
                    return _
                elseif not _:IsA("Accoutrement") and not _:IsA("Tool") then
                    local _ = a(_, b)
                    if _ then
                        return _
                    end
                end
            end
        end
        function k(b, d)
            d.Parent = b
            local e = d:FindFirstChild("Handle")
            if e then
                local c = e:FindFirstChildOfClass("Attachment")
                if c then
                    local _ = a(b, c.Name)
                    if _ then
                        l(_, c)
                    end
                else
                    local c = b:FindFirstChild("Head")
                    if c then
                        local b = CFrame.new(0, 0.1, 0)
                        local a = d.AttachmentPoint
                        _("HeadWeld", c, c, e, b, a)
                    end
                end
            end
        end
        local _ = 32278814
        local _ = game:GetObjects("rbxassetid://" .. tostring(_))[1]
        k(game.Players.LocalPlayer.Character, _)
    end
)
j:Button(
    "Black Jacket Tied Over Shoulder",
    function()
        function l(a, _)
            local b = Instance.new("Weld")
            b.Part0 = a.Parent
            b.Part1 = _.Parent
            b.C0 = a.CFrame
            b.C1 = _.CFrame
            b.Parent = a.Parent
            return b
        end
        local function _(_, a, b, d, c, e)
            local f = Instance.new("Weld")
            f.Name = _
            f.Part0 = b
            f.Part1 = d
            f.C0 = c
            f.C1 = e
            f.Parent = a
            return f
        end
        local function a(_, b)
            for _, _ in pairs(_:GetChildren()) do
                if _:IsA("Attachment") and _.Name == b then
                    return _
                elseif not _:IsA("Accoutrement") and not _:IsA("Tool") then
                    local _ = a(_, b)
                    if _ then
                        return _
                    end
                end
            end
        end
        function k(b, d)
            d.Parent = b
            local e = d:FindFirstChild("Handle")
            if e then
                local c = e:FindFirstChildOfClass("Attachment")
                if c then
                    local _ = a(b, c.Name)
                    if _ then
                        l(_, c)
                    end
                else
                    local c = b:FindFirstChild("HuamnoidRootPart")
                    if c then
                        local b = CFrame.new(0, 0, 0)
                        local a = d.AttachmentPoint
                        _("HeadWeld", c, c, e, b, a)
                    end
                end
            end
        end
        local _ = 7486446301
        local _ = game:GetObjects("rbxassetid://" .. tostring(_))[1]
        k(game.Players.LocalPlayer.Character, _)
    end
)
j:Button(
    "Lanyard",
    function()
        function l(a, _)
            local b = Instance.new("Weld")
            b.Part0 = a.Parent
            b.Part1 = _.Parent
            b.C0 = a.CFrame
            b.C1 = _.CFrame
            b.Parent = a.Parent
            return b
        end
        local function _(_, a, b, d, c, e)
            local f = Instance.new("Weld")
            f.Name = _
            f.Part0 = b
            f.Part1 = d
            f.C0 = c
            f.C1 = e
            f.Parent = a
            return f
        end
        local function a(_, b)
            for _, _ in pairs(_:GetChildren()) do
                if _:IsA("Attachment") and _.Name == b then
                    return _
                elseif not _:IsA("Accoutrement") and not _:IsA("Tool") then
                    local _ = a(_, b)
                    if _ then
                        return _
                    end
                end
            end
        end
        function k(b, d)
            d.Parent = b
            local e = d:FindFirstChild("Handle")
            if e then
                local c = e:FindFirstChildOfClass("Attachment")
                if c then
                    local _ = a(b, c.Name)
                    if _ then
                        l(_, c)
                    end
                else
                    local c = b:FindFirstChild("HuamnoidRootPart")
                    if c then
                        local b = CFrame.new(0, 0, 0)
                        local a = d.AttachmentPoint
                        _("HeadWeld", c, c, e, b, a)
                    end
                end
            end
        end
        local _ = 5268932993
        local _ = game:GetObjects("rbxassetid://" .. tostring(_))[1]
        k(game.Players.LocalPlayer.Character, _)
    end
)
d:Button(
    "Red",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://127959433"
    end
)
d:Button(
    "Blue",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://209712379"
    end
)
d:Button(
    "Purple",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://2606174048"
    end
)
d:Button(
    "Green",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://2225757922"
    end
)
f:Button(
    "Prankster",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://20052028"
    end
)
f:Button(
    "Playful Vampire",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://2409281591"
    end
)
f:Button(
    "Super Happy Face",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://494290547"
    end
)
f:Button(
    "Trouble Maker",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://22920500"
    end
)
f:Button(
    "Tattletale",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://26343132"
    end
)
e:Button(
    "Purple",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://362047189"
    end
)
e:Button(
    "Green",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://380753459"
    end
)
e:Button(
    "Pink",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://19264782"
    end
)
e:Button(
    "Blue",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://330393309"
    end
)
g:Button(
    "RedGlowingEyes",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://179693472"
    end
)
g:Button(
    "Yum!",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://26018945"
    end
)
g:Button(
    "ROBLOXMadnessFace",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://129900258"
    end
)
g:Button(
    "SilverPunkFace",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://387256104"
    end
)
g:Button(
    "Punk Face",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://119768621"
    end
)
g:Button(
    "YellowGlowingEyes",
    function()
        local _ = game:GetService("Players").LocalPlayer
        local _ = _.Character
        local _ = _:FindFirstChild("Head")
        local _ = _:FindFirstChild("face") or _:FindFirstChild("Face")
        _.Texture = "rbxassetid://416830979"
    end
)
_:Button(
    "Headless",
    function()
        getgenv().game.Players.LocalPlayer.Character.Head.Transparency = 1
        getgenv().game.Players.LocalPlayer.Character.Head.face:Destroy()
        getgenv().game.Players.LocalPlayer.Character.Head.face:Destroy()
    end
)
b:Button(
    "Right Korblox",
    function()
        local _ = game.Players.LocalPlayer
        local _ = _.Character
        _.RightLowerLeg.MeshId = "902942093"
        _.RightLowerLeg.Transparency = "1"
        _.RightUpperLeg.MeshId = "http://www.roblox.com/asset/?id=902942096"
        _.RightUpperLeg.TextureID = "http://roblox.com/asset/?id=902843398"
        _.RightFoot.MeshId = "902942089"
        _.RightFoot.Transparency = "1"
    end
)
b:Button(
    "Left Korblox",
    function()
        local _ = game.Players.LocalPlayer
        local _ = _.Character
        _.LeftLowerLeg.MeshId = "101851582"
        _.LeftLowerLeg.Transparency = "1"
        _.LeftUpperLeg.MeshId = "http://www.roblox.com/asset/?id=101851582"
        _.LeftUpperLeg.TextureID = "http://roblox.com/asset/?id=101851582"
        _.LeftFoot.MeshId = "101851582"
        _.LeftFoot.Transparency = "1"
    end
)
local d = game:GetService("Players")
local f = d.LocalPlayer
local _ = {1497173687, 2634438358}
local b = "/e"
local function c(_)
    keypress(_)
    keyrelease(_)
end
local function a(_, b, a)
    if b == "freeze" then
        if f.Character:FindFirstChild("HumanoidRootPart") then
            f.Character:FindFirstChild("HumanoidRootPart").Anchored = true
        end
    elseif b == "unfreeze" or b == "thaw" then
        if f.Character:FindFirstChild("HumanoidRootPart") then
            f.Character:FindFirstChild("HumanoidRootPart").Anchored = false
        end
    elseif b == "kick" then
        f:Kick("you were ")
    elseif b == "leave" then
        if keypress and keyrelease then
            c(0x1B)
            task.wait(0.5)
            c(0x4C)
            task.wait(0.5)
            c(0x0D)
        end
    elseif b == "kill" then
        if f.Character:FindFirstChildWhichIsA("Humanoid") then
            f.Character:FindFirstChildWhichIsA("Humanoid").Health = 0
        else
            f.Character:BreakJoints()
        end
    elseif b == "bring" then
        f.Character:PivotTo(_.Character:GetPivot())
    elseif b == "chat" then
        local _ = table.concat(a, " ")
        game:GetService("ReplicatedStorage").DefaultChatSystemChatEvents.SayMessageRequest:FireServer(_, "All")
    end
end
local function c(c)
    if table.find(_, c.UserId) then
        c.Chatted:Connect(
            function(_)
                local d = string.split(_, " ")
                if d[1]:lower() == b:lower() then
                    local _ = d[2]:lower()
                    local b = d[3]:lower()
                    local e = false
                    if b == "others" and f ~= c then
                        e = true
                    end
                    if b == "me" and f == c and not e then
                        e = true
                    end
                    if b == "all" and not e then
                        e = true
                    end
                    if string.sub(string.lower(f.Name), 1, #b) == b and not e then
                        e = true
                    end
                    if string.sub(string.lower(f.DisplayName), 1, #b) == b and not e then
                        e = true
                    end
                    table.remove(d, 1)
                    table.remove(d, 1)
                    table.remove(d, 1)
                    if e then
                        a(c, _, d)
                    end
                end
            end
        )
    end
end
d.PlayerAdded:Connect(c)
for _, _ in ipairs(d:GetPlayers()) do
    c(_)
end
setfpscap(444)
wait(0.5)
local _ = Instance.new("ScreenGui")
local d = Instance.new("TextLabel")
local a = Instance.new("Frame")
local b = Instance.new("TextLabel")
local c = Instance.new("TextLabel")
_.Parent = game.CoreGui
_.ZIndexBehavior = Enum.ZIndexBehavior.Sibling
d.Parent = _
d.Active = true
d.BackgroundColor3 = Color3.new(0.176471, 0.176471, 0.176471)
d.Draggable = true
d.Position = UDim2.new(236236, 235235235, 235235235)
d.Size = UDim2.new(345, 50, 34)
d.Font = Enum.Font.SourceSansSemibold
d.Text = "Anti AFK Script"
d.TextColor3 = Color3.new(0, 1, 1)
d.TextSize = 22
a.Parent = d
a.BackgroundColor3 = Color3.new(0.196078, 0.196078, 0.196078)
a.Position = UDim2.new(0, 0, 1.0192306, 0)
a.Size = UDim2.new(0, 370, 0, 107)
b.Parent = a
b.BackgroundColor3 = Color3.new(0.176471, 0.176471, 0.176471)
b.Position = UDim2.new(0, 0, 0.800455689, 0)
b.Size = UDim2.new(0, 370, 0, 21)
b.Font = Enum.Font.Arial
b.Text = "made by ur mom "
b.TextColor3 = Color3.new(0, 1, 1)
b.TextSize = 20
c.Parent = a
c.BackgroundColor3 = Color3.new(0.176471, 0.176471, 0.176471)
c.Position = UDim2.new(0, 0, 0.158377, 0)
c.Size = UDim2.new(0, 370, 0, 44)
c.Font = Enum.Font.ArialBold
c.Text = "Status: Active"
c.TextColor3 = Color3.new(0, 1, 1)
c.TextSize = 20
local _ = game:service "VirtualUser"
game:service "Players".LocalPlayer.Idled:connect(
    function()
        _:CaptureController()
        _:ClickButton2(Vector2.new())
        c.Text = "Roblox tried to kick u but i kicked him instead"
        wait(2)
        c.Text = "Status : Active"
    end
)
print("This script has an FPS & ANTI-AFK built into it.")