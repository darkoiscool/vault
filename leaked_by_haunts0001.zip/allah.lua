--[[
    Congratulations,
    I trust you enough to have the source code for the script.
    I Hope you enjoy your experience with this script
    Credits Below
--]]


--[[
    Credits to FLASH for the slingshot anti aim
    Everything else was made by vac.
--]]


--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]


--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]



--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]



--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]




--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]







--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]




--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]




--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]



--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]







--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]






local library = loadstring(game:HttpGet("https://raw.githubusercontent.com/bloodball/-back-ups-for-libs/main/Splix"))()



local window = library:new({
    textsize = 13.5,
    font = Enum.Font.RobotoMono,
    name = "allahakubar.lua", --name
    color = Color3.fromRGB(255, 255, 255) --ui main color accent
}) -- 225,58,81

local tab = window:page({ --makes the tab
    name = "Aiming"
})

local tab1 = window:page({ --makes the tab
    name = "Misc"
})

local tab2 = window:page({ --makes the tab
    name = "Visuals"
})

local tab3 = window:page({ --makes the tab
    name = "Teleports"
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

local section1 = tab:section({  --creates the section
    name = "Target", --name ofc 
    side = "left", --what side you want it to be on bla bla
    size = 300 --change size of secter
})

local section3 = tab1:section({  --creates the section
    name = "All Misc", --name ofc 
    side = "left", --what side you want it to be on bla bla
    size = 370 --change size of secter
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
local section4 = tab2:section({  --creates the section
    name = "Game Visuals", --name ofc 
    side = "left", --what side you want it to be on bla bla
    size = 250 --change size of secter
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
local section7 = tab2:section({  --creates the section
    name = "ESP", --name ofc 
    side = "right", --what side you want it to be on bla bla
    size = 250 --change size of secter
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
local section5 = tab3:section({  --creates the section
    name = "Teleport To Player", --name ofc 
    side = "left", --what side you want it to be on bla bla
    size = 250 --change size of secter
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
local section6 = tab3:section({  --creates the section
    name = "Teleport To Place", --name ofc 
    side = "right", --what side you want it to be on bla bla
    size = 400 --change size of secter
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

local section2 = tab:section({  --creates the section
    name = "Aimbot", --name ofc 
    side = "Right", --what side you want it to be on bla bla
    size = 250 --change size of secter
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

getgenv().Aiming = { 
    Target = { 
        Enabled = true,
        Prediction = 0.11621,
        AirshotFunc = false,
        Part = "HumanoidRootPart", -- Head UpperTorso HumanoidRootPart LowerTorso
        AirshotPart = "LowerTorso", -- i use rightfoot and rightarm
        Key = "c",
        Notifications = true,
        Toggle = false
    },
    TargetExtras = { 
        SpectatePlayer = false,
        TeleportToPlayer = false
    }
}





local CurrentCamera = game:GetService "Workspace".CurrentCamera
local Mouse = game.Players.LocalPlayer:GetMouse()
local RunService = game:GetService("RunService")
local Plr = game.Players.LocalPlayer
local lp = game.Players.LocalPlayer


Mouse.KeyDown:Connect(function(KeyPressed)
    if KeyPressed == (getgenv().Aiming.Target.Key) then
        if getgenv().Aiming.Target.Toggle == true then
        if getgenv().Aiming.Target.Enabled == true then
            getgenv().Aiming.Target.Enabled = false
            if getgenv().Aiming.Target.Notifications == true then
                Plr = FindClosestUser()
                game.StarterGui:SetCore("SendNotification", {       -------------- all of this is if key is pressed the notification will pop up and will lock on to the closest player via m2p
                    Title = "allahakubar.lua",
                    Text = "No longer locked on"
                })
            end
            if getgenv().Aiming.TargetExtras.SpectatePlayer == true then
                game.Workspace.CurrentCamera.CameraSubject = game.Players.LocalPlayer.Character
            end
        else
            Plr = FindClosestUser()
            getgenv().Aiming.Target.Enabled = true
            if getgenv().Aiming.Target.Notifications == true then
                game.StarterGui:SetCore("SendNotification", {
                    Title = "allahakubar.lua",
                    Text = "Locked on to:" .. tostring(Plr.Character.Humanoid.DisplayName)
                })
            end
            if getgenv().Aiming.TargetExtras.SpectatePlayer == true then
                game.Workspace.CurrentCamera.CameraSubject = Plr.Character
            end
            if getgenv().Aiming.TargetExtras.TeleportToPlayer == true then
                lp.Character.HumanoidRootPart.CFrame = Plr.Character.HumanoidRootPart.CFrame
            end
        end
    end
end
end)

function FindClosestUser()
    local closestPlayer
    local shortestDistance = math.huge

    for i, v in pairs(game.Players:GetPlayers()) do
        if v ~= game.Players.LocalPlayer and v.Character and v.Character:FindFirstChild("Humanoid") and
            v.Character.Humanoid.Health ~= 0 and v.Character:FindFirstChild("HumanoidRootPart") then
            local pos = CurrentCamera:WorldToViewportPoint(v.Character.PrimaryPart.Position)
            local magnitude = (Vector2.new(pos.X, pos.Y) - Vector2.new(Mouse.X, Mouse.Y)).magnitude     -- this getclosestplayer function is ass but it works ig
            if magnitude < shortestDistance then
                closestPlayer = v
                shortestDistance = magnitude
            end
        end
    end
    return closestPlayer
end







local mt = getrawmetatable(game)
local old = mt.__namecall
setreadonly(mt, false)
mt.__namecall = newcclosure(function(...)
    local args = {...}
    if getgenv().Aiming.Target.Enabled and getnamecallmethod() == "FireServer" and args[2] == "UpdateMousePos" then
        args[3] = Plr.Character[getgenv().Aiming.Target.Part].Position +
                      (Plr.Character[getgenv().Aiming.Target.Part].Velocity * getgenv().Aiming.Target.Prediction)           ----- MAIN
        return old(unpack(args))
    end
    return old(...)
end)

-- airshot function bellow then end of target code

if getgenv().Aiming.Target.AirshotFunc == true then
    if Plr.Character.Humanoid.Jump == true and Plr.Character.Humanoid.FloorMaterial == Enum.Material.Air then
        getgenv().Aiming.Target.Part = getgenv().Aiming.Target.AirshotPart
    else
        Plr.Character:WaitForChild("Humanoid").StateChanged:Connect(function(old,new)
            if new == Enum.HumanoidStateType.Freefall then
                getgenv().Aiming.Target.Part = getgenv().Aiming.Target.AirshotPart
            else
                getgenv().Aiming.Target.Part = getgenv().Aiming.Target.Part
            end
        end)
    end
end

section1:toggle({
    name = "Enable Target",
    def = false,
    callback = function(bool)
        getgenv().Aiming.Target.Toggle = bool
    end
})

section1:toggle({
    name = "Spectate Mode",
    def = false,
    callback = function(bool)
        getgenv().Aiming.TargetExtras.SpectatePlayer = bool
    end
})

section1:toggle({
    name = "Teleport Mode",
    def = false,
    callback = function(bool)
        getgenv().Aiming.TargetExtras.TeleportToPlayer = bool
    end
})

section1:textbox({
    name = "Prediction",
    def = "0.11",
    placeholder = "Enter Prediction",
    callback = function(value)
        getgenv().Aiming.Target.Prediction = value
    end
})

section1:toggle({
    name = "Airshot Function",
    def = false,
    callback = function(bool)
        getgenv().Aiming.Target.AirshotFunc = bool
    end
})
getgenv().tpuser = ""
section5:textbox({
    name = "Teleport",
    def = "",
    placeholder = "Enter Username",
    callback = function(value)
        getgenv().tpuser = value
    end
})

section5:button({
    name = "Teleport",
    callback = function()
        local pl = game.Players.LocalPlayer.Character.HumanoidRootPart
    local pl2 = getgenv().tpuser
    local humanoid = game.Players.LocalPlayer.Character.Humanoid
    humanoid:ChangeState(Enum.HumanoidStateType.Jumping)
    wait(0.1)

    pl.CFrame = game.Players[pl2].Character.HumanoidRootPart.CFrame
    end
})
local ESP = loadstring(game:HttpGet("https://pastebin.com/raw/U2HwmEyF"))()

section7:toggle({
    name = "Enable ESP",
    def = false,
    callback = function(bool)
        ESP.Enabled = bool
    end
})

section7:toggle({
    name = "ESP Boxes",
    def = false,
    callback = function(bool)
        ESP.Boxes = bool
    end
})

section7:toggle({
    name = "ESP Names",
    def = false,
    callback = function(bool)
        ESP.Names = bool
    end
})

section7:toggle({
    name = "ESP Tracers",
    def = false,
    callback = function(bool)
        ESP.Tracers = bool
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
getgenv().sped = false
getgenv().AntiAim2 = false
getgenv().jitter = false
getgenv().autoreload = false
getgenv().cframe = false
getgenv().BlatantAA = false
local Jit = math.random(30, 90)
local Angle = 60
local speedvalue = 0.50
game:GetService("RunService").Heartbeat:Connect(
    function()
        
        if sped then
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
                game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.Angles(0, math.rad(555), 0)
        end
        if AntiAim2 then

            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
                game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.new(0, 0.999, 0)
            wait(0.2)
        end

        if jitter then
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
            CFrame.new(game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame.Position) *
            CFrame.Angles(0, math.rad(Angle) + math.rad((math.random(1, 2) == 1 and Jit or -Jit)), 0)
        end
        if autoreload then
            if game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool") then
                if
                    game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool"):FindFirstChild(
                        "Ammo"
                    )
                 then
                    if
                        game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool"):FindFirstChild(
                            "Ammo"
                        ).Value <= 0
                     then
                        game:GetService("ReplicatedStorage").MainEvent:FireServer(
                            "Reload",
                            game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool")
                        )
                    end
                end
            end
        end
        if cframe then
            for _, v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
                if v:IsA("Script") and v.Name ~= "Health" and v.Name ~= "Sound" and v:FindFirstChild("LocalScript") then
                    v:Destroy()
                end
            end
            game.Players.LocalPlayer.CharacterAdded:Connect(function(char)
                repeat
                    wait()
                until game.Players.LocalPlayer.Character
                char.ChildAdded:Connect(function(child)
                    if child:IsA("Script") then 
                        wait(0.1)
                        if child:FindFirstChild("LocalScript") then
                            child.LocalScript:FireServer()
                        end
                    end
                end)
            end)
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame +
            game.Players.LocalPlayer.Character.Humanoid.MoveDirection * speedvalue
            end
            if BlatantAA then
                game.Players.LocalPlayer.Character.HumanoidRootPart.Velocity =
                game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame.lookVector * -250
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame =
                game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame * CFrame.Angles(0, math.rad(555), 0)
                end
    end)
    
section3:toggle({
    name = "Spinbot AA",
    def = false,
    callback = function(bool)

        getgenv().sped = bool
        
    end
})

section3:toggle({
    name = "Slingshot AA",
    def = false,
    callback = function(bool)

        getgenv().AntiAim2 = bool
        
    end
})

section3:toggle({
    name = "Jitter AA",
    def = false,
    callback = function(bool)

        getgenv().jitter = bool
        
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section3:toggle({
    name = "Blatant AA",
    def = false,
    callback = function(bool)

        getgenv().BlatantAA = bool
        
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

section3:toggle({
    name = "CFrame",
    def = false,
    callback = function(bool)

        getgenv().cframe = bool
        
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section3:toggle({
    name = "Auto Reload",
    def = false,
    callback = function(bool)

        getgenv().autoreload = bool
        
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

section1:dropdown({
    name = "Part",
    def = "HumanoidRootPart",
    max = 1,
    options = {"Head", "UpperTorso", "HumanoidRootPart",  "LowerTorso", "RightFoot"},
    callback = function(bool)
        getgenv().Aiming.Target.Part = bool
    end
})

section1:dropdown({
    name = "Airshot Part",
    def = "HumanoidRootPart",
    max = 1,
    options = {"Head", "UpperTorso", "HumanoidRootPart",  "LowerTorso", "RightFoot"},
    callback = function(bool)
        getgenv().Aiming.Target.AirshotPart = bool
    end
})


section1:textbox({
    name = "Key",
    def = "c",
    placeholder = "Enter Key",
    callback = function(value)
        getgenv().Aiming.Target.Key = value
    end
})

getgenv().Aimbot = { 
    Enabled = true,
    Smoothness = 0.005,
    Smoothing = false,
    AirshotFunc = false,
    AirshotPart = "RightFoot",
    AimPart = "HumanoidRootPart",
    Predicting = 1.2,
    Key = Enum.KeyCode.Q,
    Toggled
}


function x(tt,tx,cc)
    game.StarterGui:SetCore("SendNotification", {
        Title = tt;
        Text = tx;
        Duration = cc;
        Icon = "rbxthumb://type=Asset&id=7262533709&w=150&h=150";
    })
end

local CurrentCamera = game:GetService("Workspace").CurrentCamera
local RunService = game:GetService("RunService")
local Mouse = game.Players.LocalPlayer:GetMouse()
local LocalPlayer = game.Players.LocalPlayer
local Plr

function FindClosestPlayer()
    local ClosestDistance, ClosestPlayer = math.huge, nil;
    for _, Player in next, game:GetService("Players"):GetPlayers() do
        local ISNTKNOCKED = Player.Character:WaitForChild("BodyEffects")["K.O"].Value ~= true
        local ISNTGRABBED = Player.Character:FindFirstChild("GRABBING_COINSTRAINT") == nil

        if Player ~= LocalPlayer then
            local Character = Player.Character
            if Character and Character.Humanoid.Health > 1 and ISNTKNOCKED and ISNTGRABBED then
                local Position, IsVisibleOnViewPort = CurrentCamera:WorldToViewportPoint(Character.HumanoidRootPart
                                                                                             .Position)
                if IsVisibleOnViewPort then
                    local Distance = (Vector2.new(Mouse.X, Mouse.Y) - Vector2.new(Position.X, Position.Y)).Magnitude
                    if Distance < ClosestDistance then
                        ClosestPlayer = Player
                        ClosestDistance = Distance
                    end
                end
            end
        end
    end
    return ClosestPlayer, ClosestDistance
end



    game:GetService("UserInputService").InputBegan:Connect(function(keygo)
           if (keygo.KeyCode == getgenv().Aimbot.Key) then
               Toggled = not Toggled
               if Toggled then
               Plr =  FindClosestPlayer()
end
         end
           
end)
game:GetService("RunService").RenderStepped:Connect(function()
if getgenv().Aimbot.Smoothing and getgenv().Aimbot.Enabled and Toggled == true then
    local Main = CFrame.new(workspace.CurrentCamera.CFrame.p, Plr.Character[getgenv().Aimbot.AimPart].Position + Plr.Character[getgenv().Aimbot.AimPart].Velocity*getgenv().Aimbot.Predicting/10)
                                 workspace.CurrentCamera.CFrame = workspace.CurrentCamera.CFrame:Lerp(Main, getgenv().Aimbot.Smoothness, Enum.EasingStyle.Elastic, Enum.EasingDirection.InOut)
                            elseif getgenv().Aimbot.Smoothing == false and getgenv().Aimbot.Enabled and Toggled == true then
    workspace.CurrentCamera.CFrame = CFrame.new(workspace.CurrentCamera.CFrame.Position, Plr.Character[getgenv().Aimbot.AimPart].Position + Plr.Character[getgenv().Aimbot.AimPart].Velocity*getgenv().Aimbot.Predicting/10)
                            end

end)

if getgenv().Aimbot.AirshotFunc == true then
    
                if Plr.Character.Humanoid.Jump == true and Plr.Character.Humanoid.FloorMaterial == Enum.Material.Air then
                    getgenv().Aimbot.AimPart = getgenv().Aimbot.AirshotPart
                else
                    Plr.Character:WaitForChild("Humanoid").StateChanged:Connect(function(old,new)
                        if new == Enum.HumanoidStateType.Freefall then
                        getgenv().Aimbot.AimPart = getgenv().Aimbot.AirshotPart
                        else
                            getgenv().Aimbot.AimPart = getgenv().Aimbot.AimPart
                        end
                    end)
                end
            end

section2:toggle({
    name = "Enable Aimbot",
    def = false,
    callback = function(bool)
        getgenv().Aimbot.Enabled = bool
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section2:toggle({
    name = "Airshot Function",
    def = false,
    callback = function(bool)
        getgenv().Aimbot.AirshotFunc = bool
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section2:textbox({
    name = "Prediction",
    def = "1.3",
    placeholder = "Enter Prediction",
    callback = function(value)
        getgenv().Aimbot.Predicting = value
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section2:toggle({
    name = "Smoothing",
    def = false,
    callback = function(bool)
        getgenv().Aimbot.Smoothing = bool
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section2:textbox({
    name = "Smoothness",
    def = "0.0365",
    placeholder = "Enter Smoothness Amount",
    callback = function(value)
        getgenv().Aimbot.Smoothness = value
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section3:dropdown({
    name = "Autobuy",
    def = "Revolver",
    max = 1,
    options = {"Revolver", "DB", "SMG", "AK-47", "LMG", "Glock", "Silencer", "RPG", "Flamethrower", "Taser"},
    callback = function(State)
        if State == "Revolver" then
            plr = game:GetService "Players".LocalPlayer
            local gunName = "[Revolver] - $1300"
            local k = game.Workspace.Ignored.Shop[gunName]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop[gunName].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop[gunName].ClickDetector)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "DB" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Double-Barrel SG] - $1400"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Double-Barrel SG] - $1400"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Double-Barrel SG] - $1400"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "SMG" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[SMG] - $750"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[SMG] - $750"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[SMG] - $750"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "AK-47" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[AK47] - $2250"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[AK47] - $2250"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[AK47] - $2250"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "LMG" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[LMG] - $3750"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[LMG] - $3750"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[LMG] - $3750"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Glock" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Glock] - $500"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Glock] - $500"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Glock] - $500"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Silencer" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Silencer] - $550"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Silencer] - $550"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Silencer] - $550"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "RPG" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[RPG] - $6000"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[RPG] - $6000"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[RPG] - $6000"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Flamethrower" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Flamethrower] - $25000"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Flamethrower] - $25000"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Flamethrower] - $25000"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Taser" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Taser] - $1250"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Taser] - $1250"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Taser] - $1250"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        end
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section3:dropdown({
    name = "Autobuy Ammo",
    def = "Revolver",
    max = 1,
    options = {"Revolver", "DB", "SMG", "AK-47", "LMG", "Glock", "Silencer", "RPG", "Flamethrower"},
    callback = function(State)
        if State == "Revolver" then
            local plr = game:GetService "Players".LocalPlayer
            local gunName = "12 [Revolver Ammo] - $75"
            local k = game.Workspace.Ignored.Shop[gunName]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop[gunName].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop[gunName].ClickDetector)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "DB" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["18 [Double-Barrel SG Ammo] - $60"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["18 [Double-Barrel SG Ammo] - $60"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["18 [Double-Barrel SG Ammo] - $60"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "SMG" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["80 [SMG Ammo] - $60"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["80 [SMG Ammo] - $60"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["80 [SMG Ammo] - $60"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "AK-47" then
            plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["90 [AK47 Ammo] - $80"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["90 [AK47 Ammo] - $80"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["90 [AK47 Ammo] - $80"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "LMG" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["200 [LMG Ammo] - $300"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["200 [LMG Ammo] - $300"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["200 [LMG Ammo] - $300"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Glock" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["25 [Glock Ammo] - $60"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["25 [Glock Ammo] - $60"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["25 [Glock Ammo] - $60"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Silencer" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["25 [Silencer Ammo] - $50"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["25 [Silencer Ammo] - $50"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["25 [Silencer Ammo] - $50"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "RPG" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["5 [RPG Ammo] - $1000"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["5 [RPG Ammo] - $1000"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["5 [RPG Ammo] - $1000"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Flamethrower" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["140 [Flamethrower Ammo] - $1550"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["140 [Flamethrower Ammo] - $1550"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["140 [Flamethrower Ammo] - $1550"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        end
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section3:dropdown({
    name = "Autobuy Melees",
    def = "Knife",
    max = 1,
    options = {"Knife", "Bat", "Shovel", "Pitchfork", "Stopsign"},
    callback = function(State)
        if State == "Knife" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Knife] - $150"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Knife] - $150"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Knife] - $150"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Bat" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Bat] - $250"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Bat] - $250"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Bat] - $250"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Shovel" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Shovel] - $320"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Shovel] - $320"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Shovel] - $320"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Pitchfork" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Pitchfork] - $320"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Pitchfork] - $320"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Pitchfork] - $320"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Stopsign" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[StopSign] - $300"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[StopSign] - $300"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[StopSign] - $300"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        end
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section3:dropdown({
    name = "Autobuy Food",
    def = "Chicken",
    max = 1,
    options = {"Chicken", "Pizza", "Hotdog", "Taco", "Hamburger", "Donut", "Lettuce"},
    callback = function(State)
        if State == "Chicken" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Chicken] - $7"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Chicken] - $7"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Chicken] - $7"].ClickDetector)
            
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Pizza" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Pizza] - $5"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Pizza] - $5"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Pizza] - $5"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Hotdog" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[HotDog] - $8"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[HotDog] - $8"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[HotDog] - $8"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Taco" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Taco] - $2"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Taco] - $2"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Taco] - $2"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Hamburger" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Hamburger] - $5"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Hamburger] - $5"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Hamburger] - $5"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Donut" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Donut] - $5"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Donut] - $5"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Donut] - $5"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Lettuce" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Lettuce] - $5"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Lettuce] - $5"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Lettuce] - $5"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        end
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

section3:dropdown({
    name = "Autobuy Drinks",
    def = "Cranberry",
    max = 1,
    options = {"Cranberry", "Lemonade", "Starblox"},
    callback = function(State)
        if State == "Cranberry" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Cranberry] - $3"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Cranberry] - $3"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Cranberry] - $3"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Lemonade" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Lemonade] - $3"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Lemonade] - $3"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Lemonade] - $3"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        elseif State == "Starblox" then
            local plr = game:GetService "Players".LocalPlayer
            local k = game.Workspace.Ignored.Shop["[Starblox Latte] - $5"]
            local savedsilencerpos = plr.Character.HumanoidRootPart.Position
            game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = k.Head.CFrame + Vector3.new(0, 3, 0)
            wait(0.5)
            fireclickdetector(game.Workspace.Ignored.Shop["[Starblox Latte] - $5"].ClickDetector)
            fireclickdetector(game.Workspace.Ignored.Shop["[Starblox Latte] - $5"].ClickDetector)

            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
            plr.Character.HumanoidRootPart.CFrame = CFrame.new(savedsilencerpos)
        end
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]


section3:button({
    name = "AutoClicker (B)",
    callback = function()
        local time = 0.01 --decrease if too slow increase if too fast

        click = false
        m = game.Players.LocalPlayer:GetMouse()
        m.KeyDown:connect(function(key)
        if key == "b" then
        if click == true then click = false
        elseif
        click == false then click = true
        
        while click == true do 
        wait(time)
        mouse1click()
        end
        end
        end
        end)
    end
})



--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]



section4:colorpicker(
    {
        name = "Ambient",
        cpname = nil,
        def = Color3.fromRGB(255, 255, 255),
        callback = function(value)
            game:GetService("Lighting").ColorCorrection.TintColor = value
        end
    }
)

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

section4:colorpicker(
    {
        name = "Gun Chams",
        cpname = nil,
        def = Color3.fromRGB(255, 255, 255),
        callback = function(value)
            for i, v in pairs(game.Players.LocalPlayer.Backpack:GetDescendants()) do
                if v:IsA('BasePart') then
                    v.Material = 'ForceField'
                    v.Color = value
                end
            end
        end
    }
)

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

getgenv().satamount = ""

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

section4:textbox({
    name = "Saturation",
    def = "0",
    placeholder = "Enter Saturation Amount",
    callback = function(value)
        getgenv().satamount = value
        game:GetService("Lighting").ColorCorrection.Saturation = getgenv().satamount
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Revolver",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-642.438049, 21.7499943, -120.54261, -0.996704638, -4.62153764e-08, 0.0811163932, -5.21754728e-08, 1, -7.13562187e-08, -0.0811163932, -7.53533627e-08, -0.996704638)
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]

section6:button({
    name = "Bank",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-374.392303, 21.2499924, -287.927338, -0.855447054, -1.72182069e-07, -0.517890275, 2.95946307e-07, 1, -8.21309982e-07, 0.517890275, -8.55854921e-07, -0.855447054)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Admin Base",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-872.853516, -34.4276848, -538.013306, -0.999724388, -3.9898886e-08, -0.0234765243, -3.9204977e-08, 1, -3.00177518e-08, 0.0234765243, -2.90890814e-08, -0.999724388)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Rev Mountain",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-696.847717, 167.674957, -41.0118256, 0.626992583, 7.53169349e-09, -0.779025197, -1.29610933e-09, 1, 8.62493632e-09, 0.779025197, -4.39806902e-09, 0.626992583)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "UFO",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(2.85052466, 132, -736.571106, -0.0460956171, -4.24733706e-08, -0.998937011, 7.26012459e-08, 1, -4.58687275e-08, 0.998937011, -7.46384217e-08, -0.0460956171)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "RPG",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(139.815933, -22.9016266, -136.737762, 0.0339428484, -7.90177737e-08, 0.999423802, -4.7851227e-08, 1, 8.06884728e-08, -0.999423802, -5.0562452e-08, 0.0339428484)
    end
})

--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Taco",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(707.502014, 139, -543.044739, -0.00318608154, -0.00102963799, 0.999993861, 0.000187970581, 0.999999464, 0.00103024102, -0.99999404, 0.00019125198, -0.00318560796)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Drum Gun",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-80.8381271, 46.828949, -85.845993, 0.999289691, 4.71884114e-08, 0.0376862474, -4.71660684e-08, 1, -1.48225032e-09, -0.0376862474, -2.96314889e-10, 0.999289691)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Rev Roof",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-634.463135, 80.434761, -204.232559, -0.0190527271, -1.03574322e-07, -0.999818563, 4.36709335e-09, 1, -1.03676342e-07, 0.999818563, -6.3416179e-09, -0.0190527271)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]
section6:button({
    name = "Playground",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-308.851196, 103.049866, -685.874817, 0.0775452703, 4.43633544e-05, -0.996988416, 4.02679916e-06, 1, 4.48105384e-05, 0.996988416, -7.48951334e-06, 0.0775452703)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]


section6:button({
    name = "Gas Station",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(595.925171, 130.75, -346.41568, -0.0400748774, 7.26109022e-08, 0.999196708, 2.20863914e-08, 1, -7.17834538e-08, -0.999196708, 1.91919352e-08, -0.0400748774)
    end
})
--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]


section6:button({
    name = "Graveyard",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(135.109558, 99.75, -57.2315979, 0.999993503, -0.000633752206, -0.0035054055, 0.000638642872, 0.999998808, 0.00139435288, 0.00350463158, -0.00139658386, 0.999992728)
    end
})

section6:button({
    name = "School Roof",
    callback = function()
        game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = CFrame.new(-525.353455, 68.125, 311.824402, 0.999992013, 1.03866675e-08, -0.00399552286, -1.03507425e-08, 1, 9.01170427e-09, 0.00399552286, -8.97027519e-09, 0.999992013)
    end
})

-- Anyone trying to take credit for my projects WILL have a copyright claim against them.


--[[
██╗   ██╗ █████╗  ██████╗
██║   ██║██╔══██╗██╔════╝
██║   ██║███████║██║     
╚██╗ ██╔╝██╔══██║██║     
 ╚████╔╝ ██║  ██║╚██████╗
  ╚═══╝  ╚═╝  ╚═╝ ╚═════╝
--]]