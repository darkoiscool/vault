-- LES VARIABLES --
local Library = loadstring(game:HttpGet("https://raw.githubusercontent.com/slattisbabygirI/cattoware/main/Wcatto.lua"))()
Library.theme.accentcolor = Color3.fromRGB(255, 220, 25)
local _pl3298r_ = game.Players.LocalPlayer
repeat wait() until _pl3298r_.Character:FindFirstChild("FULLY_LOADED_CHAR");

local GetService = setmetatable({}, {
    __index = function(self, key)
        return game:GetService(key)
    end
})
local RunService = GetService.RunService

local savedposition
local batpos
getgenv().target = game.Players.LocalPlayer

local _1289xx__13290 = RunService.Stepped
local _plnam5478_xr = _pl3298r_.Name
local _xpSHZMisaW_ = game.Workspace.Players[_plnam5478_xr]
local MainEvent = game:GetService('ReplicatedStorage').MainEvent
local cframemovement = {
        SpeedEnabled = false,
        SpeedAmount = 5
}
getgenv().backtopos = false
getgenv().SpectateTarget = false
getgenv().AntiBag = false
getgenv().AntiStomp = false
getgenv().StompTarget = false
getgenv().AutoUseTool = false

-- LES RUNSERVICES --

_1289xx__13290:Connect(function()
    if getgenv().u == true then
    _pl3298r_.Character.HumanoidRootPart.CFrame = game.Players[target].Character.HumanoidRootPart.CFrame * CFrame.new(math.random(-8, 8), math.random(-8, 8), math.random(-8, 8))
    _pl3298r_.Character.HumanoidRootPart.Velocity = Vector3.new(0, math.random(0, 450), 0)
    end
    if game.Players[target].Character.Humanoid.Health <1 and getgenv().StompTarget == false then
        getgenv().SpectateTarget = false
        getgenv().u = false
        if getgenv().u == false and getgenv().backtopos == true then 
            _pl3298r_.Character.HumanoidRootPart.CFrame = savedposition
        end 
    elseif game.Players[target].Character.Humanoid.Health <1 and getgenv().StompTarget == true then
        getgenv().SpectateTarget = false
        getgenv().u = false
    elseif game.Players[target].Character.Humanoid.Health >99 and getgenv().StompTarget == true then
        getgenv().SpectateTarget = true
        getgenv().u = true
    end
    if getgenv().u == false then
        savedposition = (_pl3298r_.Character.HumanoidRootPart.CFrame)
    end

    if getgenv().SpectateTarget == true then
        if game.Players:FindFirstChild(target) then
                game.Workspace:FindFirstChildWhichIsA('Camera').CameraSubject = game.Players:FindFirstChild(target).Character.Humanoid
        end
    elseif getgenv().SpectateTarget == false then
        game.Workspace:FindFirstChildWhichIsA('Camera').CameraSubject = _pl3298r_.Character.Humanoid
    end
    if getgenv().AntiBag == true then
        if LocalPlayer.Character:FindFirstChild("Christmas_Sock") then
            LocalPlayer.Character:FindFirstChild("Christmas_Sock"):Destroy()
        end
    end
    if getgenv().AntiStomp == true then
        if game:GetService("Players").LocalPlayer.Character:FindFirstChild("BodyEffects"):FindFirstChild("K.O").Value == true then
            for i, v in pairs(game:GetService("Players").LocalPlayer.Character:GetChildren()) do
                if v:IsA("BasePart") then
                    v:Destroy()
                end
            end
            for i,v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
                if v:IsA('Accessory') then
                    v.Handle:Destroy()
                end
            end
        end
    end
    if getgenv().StompTarget == true then
        if game:GetService("Players")[target].Character:FindFirstChild("BodyEffects"):FindFirstChild("K.O").Value == true then
            _pl3298r_.Character.HumanoidRootPart.CFrame = game:GetService("Players")[target].Character.UpperTorso.CFrame
            MainEvent:FireServer('Stomp')
        end
    end
    if getgenv().AutoUseTool == true and getgenv().u == true then
        local tool = game.Workspace.Players[_plnam5478_xr]:FindFirstChildWhichIsA('Tool')
        tool:Activate()
    end
    if getgenv().AutoUseTool == true and getgenv().u == false then
        local tool = game.Workspace.Players[_plnam5478_xr]:FindFirstChildWhichIsA('Tool')
        tool:UnequipTools()
    end
end)

RunService.Heartbeat:Connect(function()
    for _, v in pairs(game.Players.LocalPlayer.Character:GetChildren()) do
        if v:IsA("Script") and v.Name ~= "Health" and v.Name ~= "Sound" and v:FindFirstChild("LocalScript") then
            v:Destroy()
        end
    end
    game.Players.LocalPlayer.CharacterAdded:Connect(function(char)
        repeat
            wait()
        until game.Players.LocalPlayer.Character
        char.ChildAdded:Connect(function(child)
            if child:IsA("Script") then 
                wait(0.1)
                if child:FindFirstChild("LocalScript") then
                    child.LocalScript:FireServer()
                end
            end
        end)
    end)
    if Alive(_pl3298r_) then
		if cframemovement.SpeedEnabled then
                if _pl3298r_.Character.Humanoid.MoveDirection.Magnitude > 0 then
                    for i = 1, cframemovement.SpeedAmount do
                        _pl3298r_.Character:TranslateBy(_pl3298r_.Character.Humanoid.MoveDirection)
                    end
            end
        end
    end
end)

-- LES FONCTIONS --
function Alive(Player)
    if Player and Player.Character and Player.Character:FindFirstChild("HumanoidRootPart") ~= nil and Player.Character:FindFirstChild("Humanoid") ~= nil and Player.Character:FindFirstChild("Head") ~= nil then
        return true
    end
    return false
end

-- LE SCRIPT --
local Window = Library:CreateWindow("AA", Vector2.new(400, 500), Enum.KeyCode.RightShift)

local MiscTab = Window:CreateTab("---")
local Main = MiscTab:CreateSector("...", "left")

Main:AddTextbox("Username", nil, function(Value)
	getgenv().target = Value
    function raccourcissementdupenis()
        for i,v in pairs(game.Players:GetChildren()) do
            if (string.sub(string.lower(v.Name),1,string.len(Value))) == string.lower(Value) then
                target = v.Name
            end
        end
    end
    raccourcissementdupenis()
end)

local maintoggle = Main:AddToggle('AA', false, function(Enabled)
    getgenv().u = Enabled
    if getgenv().u == false and getgenv().backtopos == true then 
        _pl3298r_.Character.HumanoidRootPart.CFrame = savedposition
    end
end)

local bakpostoggle = Main:AddToggle('Go to last position', false, function(backtopo)
    getgenv().backtopos = backtopo
end)

local spectatetoggle = Main:AddToggle('Spectate Target', false, function(spec)
    getgenv().SpectateTarget = spec
end)

local antibagtoggle = Main:AddToggle('Anti-Bag', false, function(valueab)
    getgenv().AntiBag = valueab
end)

local antistomptoggle = Main:AddToggle('Anti-Stomp', false, function(valueas)
    getgenv().AntiStomp = valueas
end)

local stomptarget = Main:AddToggle('Auto Stomp Target', false, function(valueast)
    getgenv().StompTarget = valueast
end)

local autousetoolx = Main:AddToggle("Auto Use Tool", false, function(autout)
    getgenv().AutoUseTool = autout
end)

local buybat = Main:AddButton("Buy Bat", function(buttonbat)
    batpos = (_pl3298r_.Character.HumanoidRootPart.CFrame)
    local plr = game:GetService'Players'.LocalPlayer
    local bat = '[Bat] - $250'
    local bati = game.Workspace.Ignored.Shop[bat]
    game.Players.LocalPlayer.Character.HumanoidRootPart.CFrame = bati.Head.CFrame + Vector3.new(0, 3, 0)
    wait(0.2)
    fireclickdetector(game.Workspace.Ignored.Shop[bat].ClickDetector)
    wait(0.2)
    local backpack = game.Players.LocalPlayer.Backpack
    for i,v in pairs(backpack:GetChildren()) do
        if v.Name == "[Bat]" then
            v.Parent = game.Players.LocalPlayer.Character
        end
    end
    _pl3298r_.Character.HumanoidRootPart.CFrame = batpos
end)

local toolreach = Main:AddButton("Tool Reach", function(toolreachx)
    if _pl3298r_.Character:FindFirstChildWhichIsA('Tool') then
        _pl3298r_.Character:FindFirstChildWhichIsA('Tool').Handle.Size = Vector3.new(10,10,10)
        _pl3298r_.Character:FindFirstChildWhichIsA('Tool').Handle.Transparency = 0.9
    else 
        game.StarterGui:SetCore("SendNotification", {
            Title = "Tool Reach Error!";
            Text = "You need to be holding a tool.";
            Duration = 0.5;
        })
    end
end)

local RandomTab = Window:CreateTab("---")
local RandomSector = RandomTab:CreateSector("...", "left")

local fatbutton = RandomSector:AddButton("Fat", function(x)
    game.Players.LocalPlayer.Character.Humanoid.BodyDepthScale:Destroy()
    game.Players.LocalPlayer.Character.Humanoid.BodyWidthScale:Destroy()
end)

local nojumpcooldownbutton = RandomSector:AddButton("No Jump Cooldown", function(State)
    if not game.IsLoaded(game) then 
        game.Loaded.Wait(game.Loaded);
    end
    local IsA = game.IsA;
    local newindex = nil
    newindex = hookmetamethod(game, "__newindex", function(self, Index, Value)
        if not checkcaller() and IsA(self, "Humanoid") and Index == "JumpPower" then 
            return
        end
        
        return newindex(self, Index, Value);
    end)
end)

local forceresetbutton = RandomSector:AddButton("Force Reset", function()
    for i, v in pairs(game.Players.LocalPlayer.Character:GetDescendants()) do
        if v:IsA("BasePart") then
            v:Destroy()
        end
    end
end)

local MovementSector = RandomTab:CreateSector("Movement", "right")

local SpeedToggle = MovementSector:AddToggle('Speed Enabled', false, function(State)
    cframemovement.SpeedEnabled = State
end)

SpeedToggle:AddSlider(0, 5, 10, 1, function(Value)
    cframemovement.SpeedAmount = Value
end)
SpeedToggle:AddKeybind()

local AutoReload = RandomSector:AddToggle("Auto Reload", nil, function(r)
    if r == true then
        game:GetService('RunService'):BindToRenderStep("Auto-Reload", 0 , function()
            if game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool") then
                if game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool"):FindFirstChild("Ammo") then
                    if game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool"):FindFirstChild("Ammo").Value <= 0 then
                        game:GetService("ReplicatedStorage").MainEvent:FireServer("Reload", game:GetService("Players").LocalPlayer.Character:FindFirstChildWhichIsA("Tool")) 
                        wait(1)
                    end
                end
            end
        end)
    elseif r == false then
        game:GetService('RunService'):UnbindFromRenderStep("Auto-Reload")
    end
end)

local VisualTab = Window:CreateTab("---")

local HaK = VisualTab:CreateSector("...", "left")

local HeadlessButton = HaK:AddButton("Healdess (NON FE)", function()
	game.Players.LocalPlayer.Character.Head.Transparency = 1
game.Players.LocalPlayer.Character.Head.Transparency = 1
for i,v in pairs(game.Players.LocalPlayer.Character.Head:GetChildren()) do
if (v:IsA("Decal")) then
v.Transparency = 1
end
end
end)

local Korblox = HaK:AddButton("Korblox (NON FE)", function()
	local ply = game.Players.LocalPlayer
	local chr = ply.Character
	chr.RightLowerLeg.Transparency = "1"
	chr.RightUpperLeg.MeshId = "http://www.roblox.com/asset/?id=902942096"
	chr.RightUpperLeg.TextureID = "http://roblox.com/asset/?id=902843398"
	chr.RightFoot.Transparency = "1"
end)

















--XD